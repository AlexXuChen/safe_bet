# safe_bet
Safe drive, safe bet
