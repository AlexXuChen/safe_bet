const stubData = {
  "destination_addresses" : [ "Victoria, BC, Canada" ],
  "origin_addresses" : [ "Vancouver, BC, Canada" ],
  "rows" : [
     {
        "elements" : [
           {
              "distance" : {
                 "text" : "114 km",
                 "value" : 114211
              },
              "duration" : {
                 "text" : "3 hours 4 mins",
                 "value" : 11013
              },
              "status" : "OK"
           }
        ]
     }
  ],
  "status" : "OK"
}